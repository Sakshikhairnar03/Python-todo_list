import tkinter as tk
from tkinter import messagebox
from tkinter import ttk

def add_task():
    task = entry.get()
    if task:
        listbox.insert(tk.END, task)
        entry.delete(0, tk.END)

def delete_task():
    try:
        selected_task_index = listbox.curselection()[0]
        listbox.delete(selected_task_index)
    except IndexError:
        pass

def complete_task():
    try:
        selected_task_index = listbox.curselection()[0]
        completed_task = listbox.get(selected_task_index)
        completed_listbox.insert(tk.END, completed_task)
        listbox.delete(selected_task_index)
    except IndexError:
        pass

def clear_completed_tasks():
    completed_listbox.delete(0, tk.END)

# Create the main window
root = tk.Tk()
root.title("To-Do List")
f1=("Simsun", 20, "bold")
# Set the background color to black
root.configure(bg="black")
root.geometry("650x900+50+50")

# Entry widget to enter tasks
entry = tk.Entry(root, width=40,font=f1,background="lightblue")
entry.grid(row=0, column=0, padx=10, pady=10, columnspan=3)

# Buttons for adding, deleting, and completing tasks with lavender background
button_bg = "violet"
add_button = tk.Button(root, text="Add Task",font=f1, command=add_task, bg=button_bg)
delete_button = tk.Button(root, text="Delete Task",font=f1, command=delete_task, bg=button_bg)
complete_button = tk.Button(root, text="Complete Task",font=f1, command=complete_task, bg=button_bg)
clear_completed_button = tk.Button(root, text="Clear Completed",font=f1, command=clear_completed_tasks, bg=button_bg)

add_button.grid(row=1, column=0, padx=10, pady=10)
delete_button.grid(row=1, column=1, padx=10, pady=10)
complete_button.grid(row=1, column=2, padx=10, pady=10)
clear_completed_button.grid(row=2, column=0, columnspan=3, padx=10, pady=10)

# Listbox to display tasks
listbox = tk.Listbox(root,font=f1, selectmode=tk.SINGLE, width=30,height=10 )
listbox.grid(row=3, column=0, padx=10, pady=10, columnspan=3)

# Listbox for completed tasks
completed_listbox = tk.Listbox(root,font=f1, selectmode=tk.SINGLE, width=30,height=10)
completed_listbox.grid(row=4, column=0, padx=10, pady=10, columnspan=3)

root.mainloop()
